
% Enter the names of your group members below.
% If you only have 2 group members, leave the last space blank
%
%%%%%
%%%%% NAME: Saiar Ahmed
%%%%% NAME: Francis Porca
%%%%% NAME:
%
% Add the required rules in the corresponding sections. 
% If you put the rules in the wrong sections, you will lose marks.
%
% You may add additional comments as you choose but DO NOT MODIFY the comment lines below
%

%%%%% SECTION: constants
%%%%% You do not have to add anything to this section, but feel free to change the currentYear value to test your program

orderNames([first, second, third, fourth, fifth, sixth, seventh, eighth, ninth, tenth, 
            eleventh, twelfth, thirteenth, fourteenth, fifteenth, sixteenth, seventeenth, eighteenth, nineteenth, twentytieth]).

currentYear(2023).

%%%%% SECTION: database
%%%%% Put statements for albumArtist, albumYear, albumGenre, and trackList below

albumArtist(dangerously_in_love, beyonce).
albumArtist(new_jeans_2nd_ep, newjeans).
albumArtist(beatopia, beabadoobee).
albumArtist(sawayama, rina_sawayama).
albumArtist(heaven_to_a_tortured_mind, yves_tumor).
albumArtist(igor, tyler_the_creator).
albumArtist(ctrl, sza).
albumArtist(for_lovers, lamp).
albumArtist(untourable_album, men_i_trust).
albumArtist(immunity, clairo).
albumArtist(apolonio, omar_apollo).

albumYear(dangerously_in_love, 2003).
albumYear(new_jeans_2nd_ep, 2023).
albumYear(beatopia, 2022).
albumYear(sawayama, 2020).
albumYear(heaven_to_a_tortured_mind, 2020).
albumYear(igor, 2019).
albumYear(ctrl, 2017).
albumYear(for_lovers, 2004).
albumYear(untourable_album, 2021).
albumYear(immunity, 2019).
albumYear(apolonio, 2020).

albumGenre(dangerously_in_love, rnb).
albumGenre(new_jeans_2nd_ep, kpop).
albumGenre(beatopia, indie_rock).
albumGenre(sawayama, pop).
albumGenre(heaven_to_a_tortured_mind, experimental).
albumGenre(igor, hip_hop).
albumGenre(ctrl, alternative_rnb).
albumGenre(for_lovers, jazz_pop).
albumGenre(untourable_album, bedroom_pop).
albumGenre(immunity, indie_pop).
albumGenre(apolonio, alternative_rnb).

trackList(dangerously_in_love,
         [  song(crazy_in_love, 236),
            song(naughty_girl, 208),
            song(baby_boy, 244),
            song(hip_hop_star, 222),
            song(be_with_you, 260),
            song(me_myself_and_i, 301),
            song(yes, 259),
            song(sign, 298),
            song(speechless, 360),
            song(thats_how_you_like_it, 219),
            song(the_closer, 297),
            song(dangerously, 293)
            ]).

trackList(new_jeans_2nd_ep,
         [  song(new_jeans, 108),
            song(super_shy, 154),
            song(eta, 151),
            song(cool_with_you, 147),
            song(get_up, 36),
            song(asap, 134)
         ]).

trackList(beatopia,
         [  song(10_36, 195),
            song(sunny_day, 160),
            song(ripples, 187),
            song(perfect_pair, 177),
            song(broken_cd, 170)
         ]).

trackList(sawayama,
         [  song(dynasty, 188),
            song(xs, 201),
            song(comme_des_garcons, 181),
            song(bad_friend, 208),
            song(shut, 203)
         ]).

trackList(heaven_to_a_tortured_mind,
         [  song(gospel, 198),
            song(medicine, 244),
            song(identity, 119),
            song(kerosene, 305),
            song(romanticist, 106)
         ]).

trackList(igor,
         [  song(theme, 200),
            song(earfquake, 190),
            song(i_think, 212),
            song(running, 237),
            song(new_magic, 255)
         ]).

trackList(ctrl,
         [  song(supermodel, 181),
            song(love, 275),
            song(dove, 266),
            song(drew, 291),
            song(prom, 196)
         ]).

trackList(for_lovers,
         [  song(last_train, 263),
            song(out_on, 306),
            song(tomorrow, 231),
            song(rain, 326),
            song(words, 226)
         ]).

trackList(untourable_album,
         [  song(oranon, 230),
            song(oh_dove, 316),
            song(sugar, 256),
            song(sorbitol, 258),
            song(tree, 308)
         ]).

trackList(immunity,
         [  song(alewife, 333),
            song(impossible, 350),
            song(closer_to_you, 304),
            song(north, 333),
            song(softly, 305)
         ]).

trackList(apolonio,
         [  song(amazing, 223),
            song(kamikaze, 330),
            song(want_u, 407),
            song(stayback, 239),
            song(hey_boy, 142)
         ]).


%%%%% SECTION: helpers
%%%%% Add the predicates isSong(Song), songLength(Song, Length), onAlbum(Song, Album), albumLength(Album, Length), and atNamedIndex(List, Entry, Element)
%%%%% Another other helper predicates you wish to add for your lexicon or the parser should be added here

%a
isSong(Name) :-
   trackList(_, Tracks),
   member(song(Name, _), Tracks).

%b
songLength(Name, Length) :-
   trackList(_, Tracks),
   member(song(Name, Length), Tracks).

%c
onAlbum(SongName, AlbumName) :-
    trackList(AlbumName, TrackSet),
    song_in_album(SongName, TrackSet).

song_in_album(Song, [song(Song, _)|_]).
song_in_album(Song, [_|RestTracks]) :-
    song_in_album(Song, RestTracks).

%d
albumLength(AlbumName, TotalLength) :-
   trackList(AlbumName, Tracks),
   sumTrackLengths(Tracks, TotalLength).

sumTrackLengths([], 0).
sumTrackLengths([song(_, Length)| RestTracks], TotalLength) :-
    sumTrackLengths(RestTracks, RestTotalLength),
    TotalLength is Length + RestTotalLength.


%e 
atNamedIndex(List, IndexName, Element) :-
    orderNames(OrderNames),
    find_position(OrderNames, IndexName, Position),
    find_at_index(List, Position, Element).

find_position([IndexName|_], IndexName, 1).
find_position([_|Tail], IndexName, Position) :-
    find_position(Tail, IndexName, PrevPosition),
    Position is PrevPosition + 1.

find_at_index([Element|_], 1, Element).
find_at_index([_|Tail], Position, Element) :-
    NextPosition is Position - 1,
    find_at_index(Tail, NextPosition, Element).



%%%%% SECTION: articles
%%%%% Put the rules/statements defining the proper_nouns below
article(the).
article(a). 
article(an).


%%%%% SECTION: proper_nouns
%%%%% Put the rules/statements defining the proper_nouns below
proper_noun(X) :- isSong(X).
proper_noun(X) :- albumArtist(X, _).
proper_noun(X) :- number(X).
proper_noun(X) :- albumArtist(_, X).



%%%%% SECTION: common_nouns
%%%%% Put the rules/statements defining the common_nouns below
common_noun(length, X) :- songLength(_, X).
common_noun(album, X) :- albumArtist(X, _).
common_noun(release_year, X) :- albumYear(Y, X), onAlbum(_, Y).
common_noun(genre, X) :- albumGenre(_, X).
common_noun(song, X) :- isSong(X).
common_noun(artist, X) :- albumArtist(_, X).
common_noun(length, X) :- albumLength(_, X).
common_noun(track, X) :- isSong(X).
common_noun(release_year, X) :- albumYear(_, X).
common_noun(record, X) :- albumArtist(X, _).



%%%%% SECTION: adjectives
%%%%% Put the rules/statements defining the adjectives below
adjective(Genre, X) :- albumGenre(Album, Genre), albumArtist(Album, X).
adjective(Artist, X) :- onAlbum(X, Album), albumArtist(Album, Artist).
adjective(short, X) :- songLength(X, Length), Length<180.
adjective(old, X) :- albumYear(X, Year), Year<2000.
adjective(new, X) :- albumYear(X, Year), currentYear(Y), Year=Y.
adjective(Genre, X) :- albumGenre(X, Genre).
adjective(Artist, X) :- albumArtist(X, Artist).
adjective(N, X) :- orderNames(Orders),
                    member(N, Orders),
                    albumArtist(Album, _),
                    trackList(Album, Tracks),
                    atNamedIndex(Tracks, N, song(X, _)).
adjective(short, X) :- albumLength(X, Length), Length<600.
adjective(long, X) :- songLength(X, Length), Length>359.
adjective(old, X) :- onAlbum(X, Album), albumYear(Album, Year), Year<2000.
adjective(oldest, X) :- albumYear(X, Year1), findall(Year, albumYear(Album, Year), Years), msort(Years, [H|T]), Year1=H.
adjective(new, X) :- onAlbum(X, Album), albumYear(Album, Year), currentYear(Y), Year=Y.
adjective(Genre, X) :- onAlbum(X, Album), albumGenre(Album, Genre).
adjective(long, X) :- albumLength(X, Length), Length>3599.


%%%%% SECTION: prepositions
%%%%% Put the rules/statements defining the prepositions below
preposition(released_in, X, Y) :- albumYear(X, Y).
preposition(released_in, X, Y) :- onAlbum(X, Z), albumYear(Z, Y).

preposition2(between, Album, X, Y) :- albumYear(Album, Year1), X>Y, Year1>Y, Year1<X.
preposition2(between, Album, X, Y) :- albumYear(Album, Year1), X<Y, Year1<Y, Year1>X.
preposition2(between, Song, X, Y) :- onAlbum(Song, Album),albumYear(Album, Year1), X>Y, Year1>Y, Year1<X.
preposition2(between, Song, X, Y) :- onAlbum(Song, Album),albumYear(Album, Year1), X<Y, Year1<Y, Year1>X.
preposition2(between, Song, X, Y) :- songLength(Song, Length), X>Y, Length>Y, Length<X.
preposition2(between, Song, X, Y) :- songLength(Song, Length), X<Y, Length<Y, Length>X.
preposition2(between, Album, X, Y) :- albumLength(Album, Length), X<Y, Length<Y, Length>X.
preposition2(between, Album, X, Y) :- albumLength(Album, Length), X>Y, Length>Y, Length<X.

preposition(released_before, X, Y) :- albumYear(X, Year1), albumYear(Y, Year2), Year1 < Year2.
preposition(released_before, X, Year) :- number(Year), albumYear(X, AlbumYear), AlbumYear < Year.
preposition(released_after, X, Year) :- number(Year), albumYear(X, AlbumYear), AlbumYear > Year.
preposition(released_after, X, Y) :- albumYear(X, Year1), albumYear(Y, Year2), Year1 > Year2.

preposition(with, Album, Song) :- onAlbum(Song, Album).
preposition(with, Song, Length) :- songLength(Song, Length).
preposition(with, Album, Length) :- albumLength(Album, Length).
preposition(with, Album, AlbumYear) :- albumYear(Album, AlbumYear).

preposition(of, X, Y) :- songLength(Y, X).
preposition(of, X, Y) :- songLength(X, Y).
preposition(of, X, Y) :- albumLength(Y, X). 
preposition(of, X, Y) :- albumLength(X, Y).
preposition(of, X, Y) :- onAlbum(Y, Album), albumYear(Album, X).
preposition(of, X, Y) :- albumYear(Y, X).
preposition(of, X, Y) :- albumYear(X, Y).
preposition(of, X, Y) :- onAlbum(Y, Album), albumGenre(Album, X).
preposition(of, X, Y) :- albumGenre(Y, X).
preposition(of, X, Y) :- albumGenre(X, Y).
preposition(of, X, Y) :- albumArtist(Y, X). 

preposition(on, X, Y) :- onAlbum(X, Y).

preposition(by, X, Y) :- albumArtist(X, Y).
preposition(by, X, Y) :- onAlbum(X, Z), albumArtist(Z, Y).


%%%%% SECTION: PARSER
%%%%% For testing your lexicon for question 3, we will use the default parser initially given to you.
%%%%% For testing your answers for question 4, we will use your parser below

what(Words, Ref) :- np(Words, Ref).



np([Name],Name) :- proper_noun(Name).
np([Art|Tail], What) :- article(Art), np2(Tail, What).


/* If a noun phrase starts with an article, then it must be followed
   by another noun phrase that starts either with an adjective
   or with a common noun. */

np2([Adj|Tail],What) :- adjective(Adj,What), np2(Tail, What).
np2([Noun|Tail], What) :- common_noun(Noun, What), mods(Tail,What).


/* Modifier(s) provide an additional specific info about nouns.
   Modifier can be a prepositional phrase followed by none, one or more
   additional modifiers.  */

mods([], _).
mods(Words, What) :-
	appendLists(Start, End, Words),
	prepPhrase(Start, What),mods(End, What).

prepPhrase([Prep, X|[]], What) :- number(X),
	preposition(Prep, What, X).
prepPhrase([Prep, X|Tail], What) :- number(X),
	preposition(Prep, What, X), prepPhrase(Tail,What).

prepPhrase([between, X, and, Y], What) :- number(X), number(Y),preposition2(between, What, X, Y).

prepPhrase([Prep|Tail], What) :-
	preposition(Prep, What, Ref), np(Tail, Ref).

appendLists([], L, L).
appendLists([H|L1], L2, [H|L3]) :-  appendLists(L1, L2, L3).

